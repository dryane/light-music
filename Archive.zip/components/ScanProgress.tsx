import React from "react";
import { View, StyleSheet } from "react-native";
import { StyledText } from "@/components/StyledText";
import { useInvertColors } from "@/contexts/InvertColorsContext";

interface ScanProgressProps {
  progress: number; // 0–1
}

export function ScanProgress({ progress }: ScanProgressProps) {
  const { invertColors } = useInvertColors();
  const fg = invertColors ? "#000000" : "#ffffff";
  const fgMuted = invertColors ? "#888888" : "#484848";
  const trackBg = invertColors ? "#e0e0e0" : "#1e1e1e";

  return (
    <View style={styles.container}>
      <StyledText style={[styles.label, { color: fg }]}>Scanning Library</StyledText>
      <StyledText style={[styles.sub, { color: fgMuted }]}>
        Reading metadata from your music files…
      </StyledText>
      <View style={[styles.track, { backgroundColor: trackBg }]}>
        <View
          style={[
            styles.fill,
            { backgroundColor: fg, width: `${Math.round(progress * 100)}%` },
          ]}
        />
      </View>
      <StyledText style={[styles.pct, { color: fgMuted }]}>
        {Math.round(progress * 100)}%
      </StyledText>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
    paddingHorizontal: 40,
  },
  label: {
    fontSize: 17,
    fontWeight: "600",
  },
  sub: {
    fontSize: 13,
    textAlign: "center",
    lineHeight: 18,
  },
  track: {
    width: "100%",
    height: 2,
    borderRadius: 1,
    overflow: "hidden",
  },
  fill: {
    height: "100%",
    borderRadius: 1,
  },
  pct: {
    fontSize: 11,
  },
});
