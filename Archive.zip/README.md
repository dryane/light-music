# Light Music

A LightOS-themed Android music player built on [light-template](https://github.com/vandamd/light-template).

Navigation mirrors iPhone Music:  
**Library (Artists A–Z) → Artist (album grid, oldest→newest) → Album (track list) → Now Playing (modal)**

---

## Setup

### 1. Clone the template
```bash
git clone https://github.com/vandamd/light-template light-music
cd light-music
```

### 2. Install new dependencies
```bash
bun add expo-media-library expo-av expo-music-info-2
```

### 3. Copy files

Drop everything from this zip into the matching paths. The full file map:

| File | Action |
|------|--------|
| `app.json` | Replace |
| `app/_layout.tsx` | Replace |
| `app/(tabs)/_layout.tsx` | Replace |
| `app/(tabs)/index.tsx` | Replace (Library/Artists screen) |
| `app/(tabs)/settings.tsx` | Replace |
| `app/artist/[artistId].tsx` | Add |
| `app/album/[albumId].tsx` | Add |
| `app/nowplaying.tsx` | Add |
| `contexts/PlayerContext.tsx` | Add |
| `contexts/MusicContext.tsx` | Add |
| `hooks/useMediaLibrary.ts` | Replace |
| `components/AlbumArt.tsx` | Add |
| `components/TrackRow.tsx` | Replace |
| `components/MiniPlayer.tsx` | Replace |
| `components/ScanProgress.tsx` | Add |
| `types/music.ts` | Add (create types/ folder) |

### 4. Delete /android and rebuild
```bash
rm -rf android
bunx expo run:android
```

---

## Navigation structure

```
Library (Artists A–Z, sticky alpha headers)
  └─ Artist screen  (hero + 2-col album grid, oldest→newest)
       └─ Album screen  (large art header + numbered track list)
            └─ Now Playing (modal, swipe-down to dismiss)

Mini player  ← always visible above tab bar when a track is loaded
```

---

## Features

- **Full ID3 metadata** via `expo-music-info-2` — title, artist, album, track number, year, embedded album art
- **Filename fallback** — `Artist - Title.mp3` parsed if tags are missing
- **Artists A–Z** — sticky section headers, album/song counts
- **Artist screen** — hero with shuffle button, 2-column album grid sorted oldest→newest (by year tag)
- **Album screen** — large cover art with shadow, Play + Shuffle buttons, numbered track list
- **Now Playing** — full-screen modal with seekable progress bar, prev/play-pause/next, album art
- **Mini player** — shows above tab bar only when a track is loaded; tap to open Now Playing
- **LightOS theme** — pure black/white, hairline separators, inverted-colour toggle in Settings
- **Background audio** — keeps playing when you leave the app
- **Scan progress** — shows a progress bar while reading metadata on first launch

---

## How metadata scanning works

`useMediaLibrary` paginates through all audio assets then calls `MusicInfo.getMusicInfoAsync()` on each file to get ID3 tags. Album art is cached per album so the same cover is only decoded once. The whole library is then structured into `Track → Album → Artist` objects that live in `MusicContext`, shared across all screens without re-scanning.

---

## Build for release
```bash
eas build -p android --profile production --local
```
